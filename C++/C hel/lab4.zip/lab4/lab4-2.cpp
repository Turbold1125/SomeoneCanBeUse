#include<stdio.h>
int main(){
    int a,b;
    scanf("%d %d", &a, &b) ;
    if(a==b) {						// if (a==b); gej bichsen n bichigleliin aldaa { } haaltiig if else araas zaaval 
        printf("tentsuu\n") ;			 														//tavij bichih ystoi
    }								//mun if(a==b); gej bichsen n bichigleliin aldaa ";"-g bicheegui bol programm asuudalgui ajillna.
    else {
    	printf("yalgaatai\n");
	}
}
