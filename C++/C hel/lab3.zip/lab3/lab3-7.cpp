#include<stdio.h>
int main(){
	int x,neg,hoyr,gurav,duruv,tav,zurgaa,doloo,naim,ys;
	printf("x=");
	scanf("%d",&x);																				//x-g garaas oruulah
neg=x<10 && printf("1 orontoi too\n"); 															//1 orontoi toog shalgah
	hoyr=x>=10 && x<100 && printf("2 orontoi too\n");											//2 orontoi toog shalgah
		gurav=x>=100 && x<1000 && printf("3 orontoi too\n");									//3 orontoi toog shalgah
			duruv=x>=1000 && x<10000 && printf("4 orontoi too\n");								//4 orontoi toog shalgah
				tav=x>=10000 && x<100000 && printf("5 orontoi too\n");							//5 orontoi toog shalgah
					zurgaa=x>=100000 && x<1000000 && printf("6 orontoi too\n");					//6 orontoi toog shalgah
						doloo=x>=1000000 && x<10000000 && printf("7 orontoi too\n");			//7 orontoi toog shalgah
							naim=x>=10000000 && x<100000000 && printf("8 orontoi too\n");		//8 orontoi toog shalgah
								ys=x>=100000000 && x<1000000000 && printf("9 orontoi too\n");	//9 orontoi toog shalgah
							
										
	
}
