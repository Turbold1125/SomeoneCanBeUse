#include<stdio.h>
int main(){
	int a=9,b=11,c=10;
	c<b && a<c && printf("bolj");
	(a%3 == 0 || c%5 == 3) && printf("bna.\n");
}
