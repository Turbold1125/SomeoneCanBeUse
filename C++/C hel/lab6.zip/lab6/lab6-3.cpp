#include<stdio.h>
int main(){
	int a[100];
	int b[100];
	int c[100];
	int i, j, n, m, k;
	printf("n too ba m too=");
	scanf("%d", &n);
	scanf("%d", &m);
	printf("A husnegtend=");
	for (i=0; i<n; i++){
		scanf("%d", &a[i]);
	}
	printf("B husnegtend=");
	for (j=0; j<m; j++){
		scanf("%d", &b[j]);
	}
	printf("C husnegtend=");
	for (i=0; i<n; i++){
		c[k]=a[i];
		printf("%d ",c[k]);
	} for (j=0; j<m; j++){
		c[k]=b[j];
		printf("%d ", c[k]);
	}
}

