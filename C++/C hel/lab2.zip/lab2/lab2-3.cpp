#include<stdio.h>
int main(){
	int on=2000,sar=2, udur=2;
	printf("bi %d onii %d sariin %d -nd tursun.", on, sar, udur);
}
