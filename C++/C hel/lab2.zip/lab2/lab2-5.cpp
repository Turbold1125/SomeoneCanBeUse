#include<stdio.h>
#include<math.h>
int main(){
	int a, b, nemeh, hasah, huvi, urjih;
	float huvaah;
	scanf("%d %d",&a , &b);
	printf("nemeh : %d\n", nemeh=a+b);
	printf("hasah : %d\n", hasah=a-b);
	printf("huvi : %d\n", huvi=a%b);
	printf("urjih : %d\n", urjih=a*b);
	printf("huvaah : %.2f\n", huvaah=(double)a/b);
}
