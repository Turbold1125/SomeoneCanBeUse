#include<stdio.h>
int main(){
	int y=2018, m=2, d=5;
	printf("unuudur %d onii %d sariin %d udur", y,m,d);
}
