#include<stdio.h>
int main(){
	printf("Sain baina uu? C hel");
}

