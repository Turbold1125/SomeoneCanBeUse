#include<stdio.h>
int main(){
	int y, m, d;
	printf("on");
	scanf("%d", &y);
	printf("sar");
	scanf("%d", &m);
	printf("udur");
	scanf("%d", &d);

	printf("Unuudur %d onii %d sariin %d udur bn" , y, m, d);
	
}



