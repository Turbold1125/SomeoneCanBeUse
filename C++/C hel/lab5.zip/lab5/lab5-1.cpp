#include<stdio.h>
int main(){
	int n,i;
	printf("n=");
	scanf("%d",&n);
	for (i = 0; i < n; i++){
	printf("programming in c\n");
	}
	return 0;
}
