#include<stdio.h>
int main(){
	int i,n=31,j;
	for(i = 1; i<=31; i++){
		if (i==8){
			printf("%d---davaa(amralt)\n",i);
		 	}if (i==1 || i==15 || i== 22 || i==29){
					printf("%d---davaa\n",i);
		 		}if (i==2 || i==9 || i== 16 || i== 23 || i==30){
						printf("%d---myagmar\n",i);
		 			}if (i==3 || i==10 || i== 17 || i== 24 || i==31){
							printf("%d---lhagva\n",i);
		 				}if (i==4 || i==11 || i== 18 || i== 25){
								printf("%d---purev\n",i);
		 					}if (i==5 || i==12 || i== 19 || i== 26){
									printf("%d---baasan\n",i);
		 						}if (i==6 || i==13 || i== 20 || i== 27){
										printf("%d---byamba(amralt)\n",i);
		 							}if (i==7 || i==14 || i== 21 || i== 28){
											printf("%d---nyam(amralt)\n",i);
										}
	}
}
