#include<stdio.h>
int main()
{
	printf("*   *\t*****\t*    \t*    \t*****\n");
	printf("*   *\t*    \t*    \t*    \t*   *\n");
	printf("*   *\t*    \t*    \t*    \t*   *\n");
	printf("*****\t*****\t*    \t*    \t*   *\n");
	printf("*   *\t*    \t*    \t*    \t*   *\n");
	printf("*   *\t*    \t*    \t*    \t*   *\n");
	printf("*   *\t*****\t*****\t*****\t*****\n");
}

